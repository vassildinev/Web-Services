﻿namespace RealEstateSystem.Web.Infrastructure.Mappings
{
    public interface IMapFrom<T>
    {
    }
}
