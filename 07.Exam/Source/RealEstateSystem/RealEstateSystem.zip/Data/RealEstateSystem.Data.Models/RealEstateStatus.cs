﻿namespace RealEstateSystem.Data.Models
{
    public enum RealEstateStatus
    {
        ForRenting = 0,
        ForSelling = 1,
        ForRentingAndSelling = 2
    }
}