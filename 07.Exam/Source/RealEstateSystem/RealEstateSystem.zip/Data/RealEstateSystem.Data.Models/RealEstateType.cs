﻿namespace RealEstateSystem.Data.Models
{
    public enum RealEstateType
    {
        Apartment = 0,
        House = 1,
        Office = 2,
        Storehouse = 3
    }
}